# Dynamo & llm-d — GLM-4.7-FP8 / MiniMax-M2.7 Benchmark Package

## Contents

```
manifests/
  dynamo/
    glm47-agg.yaml       GLM-4.7-FP8, Dynamo aggregated  (2× independent TP=8 workers)
    glm47-disagg.yaml    GLM-4.7-FP8, Dynamo disaggregated  (prefill + decode, NIXL KV transfer)
    minimax-agg.yaml     MiniMax-M2.7, Dynamo aggregated
    minimax-disagg.yaml  MiniMax-M2.7, Dynamo disaggregated
  llmd/
    glm47-agg.yaml       GLM-4.7-FP8, llm-d aggregated  (plain vLLM, no router)
    glm47-disagg.yaml    GLM-4.7-FP8, llm-d disaggregated (NIXL + EPP router)
benchmark.py             Standalone benchmark script (no extra deps beyond requests)
01_GLM47_Benchmark.ipynb
02_MiniMax_Benchmark.ipynb
03_Dynamo_vs_llmd.ipynb
```

## Prerequisites

| Requirement | Notes |
|---|---|
| Kubernetes cluster | GPU nodes with H100 80GB (8× per node) |
| `nvidia.com/dynamo` CRDs | Install from [NVIDIA Dynamo GitHub](https://github.com/ai-dynamo/dynamo) |
| `ngc-registry` image pull secret | `nvcr.io/nvidia/ai-dynamo/vllm-runtime:1.2.1` |
| Model weights cached locally | Path configured as `hostPath` in each manifest |
| NATS server | Running in the `dynamo` namespace (required for disagg configs) |
| InfiniBand / RDMA | Required for cross-node KV transfer in disagg configs |

## Quick Start

### 1. Adapt node names

Replace all `<YOUR-*-NODE>` placeholders in the YAML files with your actual Kubernetes node hostnames:

```bash
grep -r "<YOUR" manifests/
```

For disaggregated configs, also set:
- `NATS_SERVER` — ClusterIP of your NATS service: `kubectl get svc -n dynamo | grep nats`
- `UCX_NET_DEVICES` — IB device name, e.g. `mlx5_0:1` (check with `ibv_devinfo | grep hca_id`)
- `NCCL_SOCKET_IFNAME` — Ethernet interface name for NCCL bootstrap (e.g. `enp41s0np0`)

### 2. Deploy

```bash
# Dynamo namespace
kubectl create namespace dynamo --dry-run=client -o yaml | kubectl apply -f -

# GLM-4.7-FP8 — aggregated
kubectl apply -n dynamo -f manifests/dynamo/glm47-agg.yaml

# Watch startup (workers take ~5 min to load)
kubectl get pods -n dynamo -w
```

### 3. Run benchmark

```bash
pip install requests

# Test against Dynamo GLM aggregated (NodePort 30821)
python benchmark.py --url http://<ANY-NODE>:30821 --model glm-4.7-fp8 --out glm_agg.json

# Test against Dynamo GLM disaggregated (NodePort 30823)
python benchmark.py --url http://<ANY-NODE>:30823 --model glm-4.7-fp8 --out glm_disagg.json
```

### 4. Scale disaggregated configs (no redeploy)

```bash
# GLM: 1P1D → 2P1D (double prefill capacity)
kubectl patch dgd glm47-disagg -n dynamo --type=merge \
  -p '{"spec":{"services":{"VllmPrefillWorker":{"replicas":2}}}}'

# GLM: 2P1D → 2P2D
kubectl patch dgd glm47-disagg -n dynamo --type=merge \
  -p '{"spec":{"services":{"VllmDecodeWorker":{"replicas":2}}}}'
```

## Benchmark Tests

| Test | Input | Output | Concurrency | What it measures |
|------|-------|--------|-------------|-----------------|
| A — Latency sweep | 1K tokens | 200 tokens | 1, 5, 10, 20 | Latency under load (p50, p95) |
| B — Output sweep | 1K tokens | 200 → 20K tokens | 5 | Throughput at long outputs |

## Config Summary

| Config | Framework | Workers | Topology | Key flags |
|--------|-----------|---------|----------|-----------|
| GLM Agg×2 | Dynamo | 2×TP=8 | Aggregated | `--enable-prefix-caching` |
| GLM Disagg | Dynamo | 1P + 1D (TP=8 each) | P/D separated | NIXL RDMA, KV router, `--enable-eplb` |
| MiniMax Agg×2 | Dynamo | 2×TP=8 | Aggregated | CUDA graph (FULL_DECODE_ONLY) |
| MiniMax Disagg | Dynamo | 1P + 1D (TP=8 each) | P/D separated | NIXL RDMA, KV router, `--enable-eplb` |
| GLM Agg×2 | llm-d | 2×TP=8 | Aggregated | Standard vLLM, no router |
| GLM Disagg | llm-d | 1P + 1D (TP=8 each) | P/D separated | NIXL RDMA, EPP router |

## Benchmark Methodology & Fairness

All results were produced on the exact configurations above. Two features in the Dynamo
disaggregated configs deserve explanation, since they might appear asymmetric at first glance:

**KV-aware routing (`DYN_ROUTER_MODE=kv`)** routes each request to the decode worker most
likely to already hold the matching KV cache prefix. The benchmarks use a synthetic
fixed-length prompt repeated across requests — every request looks identical to the router, so
the KV cache is never warm across different clients. In practice the router falls back to
round-robin and may add a small routing-decision overhead. It did not bias results in Dynamo's
favour.

**EPLB (`--enable-eplb`)** dynamically rebalances MoE expert assignment based on observed
token distributions. On the synthetic uniform workload used here it adds approximately 5%
scheduling overhead with no throughput gain, meaning Dynamo's disagg numbers were slightly
*penalised* by having it on, not helped.

Both features were enabled because that is exactly how the system was deployed and run — the
manifests in this package reflect the actual state during benchmarking.

**For real-data comparisons:** both features become meaningful. If you switch to in-domain or
production traffic, enable them on both sides symmetrically:
- Dynamo: KV router is already on in the disagg manifests; also uncomment it in the agg manifests.
- llm-d: enable the EPP scheduler (deploy an `InferencePool` + `InferenceModel`) so llm-d also
  gets KV-aware routing — otherwise the comparison would favour Dynamo.
- EPLB applies only to Dynamo (llm-d does not have an equivalent today).

---

## Extending to Real-World Data

The notebooks and manifests in this package use a synthetic fixed-length prompt for
reproducibility. When running with real production traffic or domain-specific data,
the following additions are recommended to unlock the full capability of each framework.

### 1. KV-aware routing (prefix reuse)

When requests share common prefixes — system prompts, few-shot examples, RAG context,
tool schemas — routing requests to the worker that already holds the matching KV cache
eliminates redundant prefill computation and significantly reduces TTFT.

**Dynamo disagg manifests:** KV router (`DYN_ROUTER_MODE=kv`) is already enabled —
this matches what was actually run. Additionally uncomment it in the agg manifests
(`glm47-agg.yaml`, `minimax-agg.yaml`) for those configs to also benefit.

**llm-d:** deploy an `InferencePool` and `InferenceModel` to enable the EPP
(Endpoint Picker Protocol) scheduler alongside. The EPP router scores each worker by
estimated KV cache overlap and routes accordingly. Enable this on the llm-d side too
so both frameworks are tested with their KV-aware routing active — otherwise the
comparison would not be symmetric.

### 2. EPLB — Expert Parallel Load Balancing (MoE models)

GLM-4.7 and MiniMax-M2.7 are Mixture-of-Experts models. Real domain data tends to
activate a skewed subset of experts repeatedly (domain vocabulary → domain experts),
creating throughput bottlenecks on the hot experts.

**Dynamo disagg manifests:** `--enable-eplb` is already enabled on both prefill and
decode workers — this matches what was actually run. EPLB monitors per-expert token
counts at runtime and rebalances assignment across GPUs. On synthetic uniform prompts
it adds ~5% scheduling overhead with no gain; on in-domain data the improvement is
typically 5–15% aggregate throughput. llm-d does not have an equivalent feature today.

### 3. Real dataset / trace replay

Replace the synthetic `build_prompt()` call in the notebooks with your own data:

```python
# Example: load prompts from a JSONL file
import json
prompts = [json.loads(l)["prompt"] for l in open("your_data.jsonl")]
```

Alternatively, use the [Mooncake FAST'25 toolagent trace](https://github.com/kvcache-ai/Mooncake/tree/main/FAST25-release/traces)
— 23,608 real production tool-agent requests with ~59% prefix reuse ratio —
as a public stand-in for domain traffic. Replay it with `aiperf`:

```bash
pip install aiperf==0.10.0
aiperf profile \
  -m glm-4.7-fp8 \
  --tokenizer THUDM/glm-4-9b-chat \
  --input-file toolagent_trace.jsonl \
  --custom-dataset-type mooncake_trace \
  --trace-block-size 512 \
  --fixed-schedule \
  --url http://<YOUR-NODE>:30821 \
  --streaming \
  --artifact-dir ./results
```

This workload is where KV routing and EPLB produce the largest measurable differences
between configurations.

### 4. Reproducibility

Set a fixed random seed and run at least 3 rounds, discarding the first (warmup):

```python
import random, numpy as np
random.seed(42)
np.random.seed(42)
```

Report p50 and p95 latency averaged across rounds rather than single-run numbers.
