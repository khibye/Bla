"""
Benchmark script for GLM-4.7-FP8 and MiniMax-M2.7 on NVIDIA Dynamo and llm-d.

Runs two tests per endpoint:
  Test A — Latency sweep: fixed input/output length, vary concurrency (1/5/10/20)
  Test B — Output length sweep: fixed concurrency, vary output length (200/2000/5000/10000/20000 tokens)

Usage:
    python benchmark.py --url http://<NODE>:<PORT> --model <MODEL-NAME> [--out results.json]

Examples:
    # Dynamo GLM aggregated
    python benchmark.py --url http://NODE:30821 --model glm-4.7-fp8

    # llm-d GLM disaggregated (router)
    python benchmark.py --url http://NODE:30830 --model glm-4.7-fp8

    # MiniMax
    python benchmark.py --url http://NODE:30824 --model minimax-m2.7

Requirements:
    pip install requests
"""

import argparse
import json
import pathlib
import statistics
import threading
import time

import requests


# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------

_WORDS = ("The quick brown fox jumps over the lazy dog . "
          "A stitch in time saves nine . "
          "All that glitters is not gold . ").split()


def build_prompt(n_tokens: int) -> str:
    cycle = _WORDS * (n_tokens // len(_WORDS) + 1)
    return " ".join(cycle[:n_tokens])


# ---------------------------------------------------------------------------
# Single request
# ---------------------------------------------------------------------------

def send_request(url: str, model: str, prompt: str, max_tokens: int,
                 timeout: int = 600) -> dict:
    t0 = time.monotonic()
    try:
        r = requests.post(
            f"{url}/v1/chat/completions",
            json={
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_tokens,
                "temperature": 0,
            },
            timeout=timeout,
        )
        elapsed = time.monotonic() - t0
        if r.status_code != 200:
            return {"error": r.status_code, "latency": elapsed}
        usage = r.json().get("usage", {})
        return {
            "latency": elapsed,
            "input_tokens":  usage.get("prompt_tokens", 0),
            "output_tokens": usage.get("completion_tokens", 0),
        }
    except Exception as e:
        return {"error": str(e), "latency": time.monotonic() - t0}


# ---------------------------------------------------------------------------
# Concurrent load driver
# ---------------------------------------------------------------------------

def run_load(url: str, model: str, n_input: int, n_output: int,
             concurrency: int, n_requests: int = 30) -> dict:
    prompt = build_prompt(n_input)
    latencies, output_tokens, errors = [], [], 0
    lock = threading.Lock()
    sem = threading.Semaphore(concurrency)

    def worker():
        nonlocal errors
        with sem:
            res = send_request(url, model, prompt, n_output)
            with lock:
                if "error" in res:
                    errors += 1
                else:
                    latencies.append(res["latency"])
                    output_tokens.append(res["output_tokens"])

    threads = [threading.Thread(target=worker) for _ in range(n_requests)]
    t_start = time.monotonic()
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    elapsed_total = time.monotonic() - t_start

    if not latencies:
        return {"error": "all requests failed", "n_errors": errors}

    s = sorted(latencies)
    total_output = sum(output_tokens)
    return {
        "n":          len(latencies),
        "errors":     errors,
        "p50_s":      round(s[len(s) // 2], 3),
        "p95_s":      round(s[int(len(s) * 0.95)], 3),
        "mean_s":     round(statistics.mean(latencies), 3),
        "tok_per_s":  round(total_output / elapsed_total, 1),
    }


# ---------------------------------------------------------------------------
# Test A — Latency / concurrency sweep
# ---------------------------------------------------------------------------

def test_a(url: str, model: str) -> dict:
    """Fixed prompt (1K input, 200 output), sweep concurrency."""
    print("\n[Test A] Latency sweep — 1K input tokens, 200 output tokens")
    results = {}
    for c in [1, 5, 10, 20]:
        n_req = max(c * 3, 20)
        print(f"  C={c:2d}  ({n_req} requests) ...", end=" ", flush=True)
        r = run_load(url, model, n_input=1000, n_output=200,
                     concurrency=c, n_requests=n_req)
        results[f"C{c}"] = r
        if "error" in r:
            print(f"ERROR: {r['error']}")
        else:
            print(f"p50={r['p50_s']:.2f}s  p95={r['p95_s']:.2f}s  "
                  f"tok/s={r['tok_per_s']:.1f}")
    return results


# ---------------------------------------------------------------------------
# Test B — Output length sweep
# ---------------------------------------------------------------------------

def test_b(url: str, model: str) -> dict:
    """Fixed concurrency (C=5), sweep output length."""
    print("\n[Test B] Output length sweep — C=5, 1K input tokens")
    results = {}
    for n_out in [200, 2000, 5000, 10_000, 20_000]:
        print(f"  out={n_out:6d} ...", end=" ", flush=True)
        r = run_load(url, model, n_input=1000, n_output=n_out,
                     concurrency=5, n_requests=15)
        results[f"out{n_out}"] = r
        if "error" in r:
            print(f"ERROR: {r['error']}")
        else:
            print(f"p50={r['p50_s']:.2f}s  tok/s={r['tok_per_s']:.1f}")
    return results


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="LLM inference benchmark")
    parser.add_argument("--url",   required=True, help="Endpoint base URL, e.g. http://node:30821")
    parser.add_argument("--model", required=True, help="Served model name, e.g. glm-4.7-fp8")
    parser.add_argument("--out",   default="results.json", help="Output JSON file")
    parser.add_argument("--skip-a", action="store_true", help="Skip Test A")
    parser.add_argument("--skip-b", action="store_true", help="Skip Test B")
    args = parser.parse_args()

    # Sanity check
    print(f"Checking {args.url}/v1/models ...")
    try:
        r = requests.get(f"{args.url}/v1/models", timeout=15)
        models = [m["id"] for m in r.json().get("data", [])]
        print(f"  Available models: {models}")
        if args.model not in models:
            print(f"  WARNING: '{args.model}' not found in model list")
    except Exception as e:
        print(f"  Could not reach endpoint: {e}")
        return

    out_path = pathlib.Path(args.out)
    data = json.loads(out_path.read_text()) if out_path.exists() else {}

    if not args.skip_a:
        data["test_a"] = test_a(args.url, args.model)

    if not args.skip_b:
        data["test_b"] = test_b(args.url, args.model)

    out_path.write_text(json.dumps(data, indent=2))
    print(f"\nResults saved to {out_path}")


if __name__ == "__main__":
    main()
